from sqlalchemy import MetaData
from sqlalchemy.ext.declarative import declarative_base


Base = declarative_base(metadata=MetaData(schema='metaschema'))

